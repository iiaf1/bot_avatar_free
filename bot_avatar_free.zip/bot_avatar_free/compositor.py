#!/usr/bin/env python3
### ══════════════════════════════════════════════════════════════════
### Bot Avatar Free
### © 2026 iaf1 — جميع الحقوق محفوظة | All Rights Reserved.
### 🚫 البيع ممنوع منعًا باتًا | Selling is strictly PROHIBITED.
### ✅ ملفات مجانية 100% | These files are 100% FREE.
### ⚠️ إخلاء مسؤولية: مقدّمة "كما هي" بدون أي ضمان، والمؤلف غير مسؤول
###    عن أي ضرر أو خسارة أو سوء استخدام ناتج عنها.
### 📄 الشروط الكاملة: ملف LICENSE
### 📬 Discord: iaf0 | GitHub: https://github.com/iiaf1
### ══════════════════════════════════════════════════════════════════
"""
Compositor: takes a profile photo + a background image and drops them into
Path.png -- photo inside the avatar circle, background behind it (filling
the whole card, sky + bottom bar), while the dark ring around the circle,
the orange "idle" status badge, and the rounded card border stay exactly
as in the original template.

Path.png geometry was measured directly from the template (840x540):
    - sky area only (where the user's background image goes): x[33:806],
      y[32:292] -- the black bottom bar (y 292-508) is left untouched and
      always stays solid black, the background image never bleeds into it.
    - avatar circle: center (143.5, 347.5); the photo fills all the way out
      to radius 103 (the outer edge of the template's dark separator ring)
      so there's no visible gap between the photo and the circle's outline.
    - status badge notch (must stay on top, never covered): center
      (203.5, 415.5), radius 36 (covers the dark separator ring + badge)

CLI usage:
    python3 compositor.py --photo photo.jpg --background bg.jpg --out result.png
    python3 compositor.py --photo photo.jpg --out result.png   # keeps original dark background
"""

import argparse
from pathlib import Path

import numpy as np
from PIL import Image, ImageFilter, ImageOps

__author__ = "iaf1"
__copyright__ = "Copyright (c) 2026 iaf1. All Rights Reserved."
__license__ = "Bot Avatar Free License - Free use only, selling strictly prohibited (see LICENSE)"

BASE = Path(__file__).parent
FRAME_PATH = BASE / "Path.png"

# ---- geometry measured from Path.png (see docstring above) ----
CARD_X0, CARD_X1 = 33, 806
SKY_Y0, SKY_Y1 = 32, 292  # sky only -- the black bar below stays untouched
SKY_CORNER_R = 22  # the sky's top-left/top-right corners are rounded, matching the card's outer border curve
CIRCLE_CENTER = (143.5, 347.5)
CIRCLE_RADIUS = 103  # outer edge of the ring -> photo touches the outline, no gap
BADGE_CENTER = (203.5, 415.5)
BADGE_RADIUS = 36  # includes the dark ring around the badge


def _dilate(mask: np.ndarray, px: int = 1) -> np.ndarray:
    m_img = Image.fromarray((mask * 255).astype(np.uint8))
    for _ in range(px):
        m_img = m_img.filter(ImageFilter.MaxFilter(3))
    return np.array(m_img) > 0


def _disc_mask(shape, center, radius) -> np.ndarray:
    h, w = shape
    yy, xx = np.mgrid[0:h, 0:w]
    cx, cy = center
    return (xx - cx) ** 2 + (yy - cy) ** 2 <= radius ** 2


def _circle_mask(frame_rgb: np.ndarray):
    """Avatar circle -> where the user's photo goes (badge notch excluded
    so the status badge always stays visible on top)."""
    shape = frame_rgb.shape[:2]
    disc = _disc_mask(shape, CIRCLE_CENTER, CIRCLE_RADIUS)
    badge = _disc_mask(shape, BADGE_CENTER, BADGE_RADIUS)
    return disc & ~badge, CIRCLE_CENTER, CIRCLE_RADIUS


def _card_bg_mask(frame_rgb: np.ndarray):
    """Sky area only (NOT the black bottom bar, which always stays solid
    black) minus the avatar circle and the status badge notch -> where the
    user's background image goes. The top-left/top-right corners are
    rounded to match the card's own border curve, so the background never
    pokes a square corner into the rounded border."""
    shape = frame_rgb.shape[:2]
    h, w = shape
    yy, xx = np.mgrid[0:h, 0:w]
    sky = (xx >= CARD_X0) & (xx <= CARD_X1) & (yy >= SKY_Y0) & (yy <= SKY_Y1)

    r = SKY_CORNER_R
    # top-left corner box -> keep only the pixels inside the rounding curve
    tl_box = (xx < CARD_X0 + r) & (yy < SKY_Y0 + r)
    tl_cut = tl_box & ((xx - (CARD_X0 + r)) ** 2 + (yy - (SKY_Y0 + r)) ** 2 > r ** 2)
    # top-right corner box
    tr_box = (xx > CARD_X1 - r) & (yy < SKY_Y0 + r)
    tr_cut = tr_box & ((xx - (CARD_X1 - r)) ** 2 + (yy - (SKY_Y0 + r)) ** 2 > r ** 2)

    sky = sky & ~tl_cut & ~tr_cut
    circle = _disc_mask(shape, CIRCLE_CENTER, CIRCLE_RADIUS + 4)
    badge = _disc_mask(shape, BADGE_CENTER, BADGE_RADIUS)
    return sky & ~circle & ~badge


def _cover_resize(img: Image.Image, w: int, h: int) -> Image.Image:
    """Resize+crop an image to exactly (w, h), covering the whole area (like CSS background-size:cover)."""
    return ImageOps.fit(img.convert("RGB"), (w, h), Image.LANCZOS, centering=(0.5, 0.5))


def make_framed(photo_path, background_path=None) -> Image.Image:
    frame_img = Image.open(FRAME_PATH).convert("RGB")
    frame_rgb = np.array(frame_img)
    h, w = frame_rgb.shape[:2]

    out = frame_rgb.copy()

    # 1) background layer (behind the circle) -----------------------------
    if background_path is not None:
        bg_mask = _card_bg_mask(frame_rgb)
        ys, xs = np.where(bg_mask)
        bx0, bx1, by0, by1 = xs.min(), xs.max(), ys.min(), ys.max()
        bg_img = _cover_resize(Image.open(background_path), bx1 - bx0 + 1, by1 - by0 + 1)
        bg_full = Image.new("RGB", (w, h), (0, 0, 0))
        bg_full.paste(bg_img, (bx0, by0))
        bg_full_arr = np.array(bg_full)
        out[bg_mask] = bg_full_arr[bg_mask]

    # 2) photo layer (inside the circle), drawn on top of the background --
    circle_mask, center, radius = _circle_mask(frame_rgb)
    diameter = int(radius * 2) + 6
    photo_img = _cover_resize(Image.open(photo_path), diameter, diameter)
    photo_full = Image.new("RGB", (w, h), (0, 0, 0))
    cx, cy = center
    left, top = int(cx - diameter / 2), int(cy - diameter / 2)
    photo_full.paste(photo_img, (left, top))
    photo_full_arr = np.array(photo_full)
    out[circle_mask] = photo_full_arr[circle_mask]

    return Image.fromarray(out, "RGB")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--photo", required=True, help="path to the profile photo (goes inside the circle)")
    ap.add_argument("--background", default=None, help="path to the background image (goes behind the circle)")
    ap.add_argument("--out", default="result.png")
    args = ap.parse_args()

    result = make_framed(args.photo, args.background)
    result.save(args.out)
    print(f"saved -> {args.out}")
    print("© 2026 iaf1 — All Rights Reserved | Free • Selling PROHIBITED | Discord: iaf0 | https://github.com/iiaf1")


if __name__ == "__main__":
    main()

### ══════════════════════════════════════════════════════════════════
### Bot Avatar Free
### © 2026 iaf1 — جميع الحقوق محفوظة | All Rights Reserved.
### 🚫 البيع ممنوع منعًا باتًا | Selling is strictly PROHIBITED.
### ✅ ملفات مجانية 100% | These files are 100% FREE.
### ⚠️ إخلاء مسؤولية: مقدّمة "كما هي" بدون أي ضمان، والمؤلف غير مسؤول
###    عن أي ضرر أو خسارة أو سوء استخدام ناتج عنها.
### 📄 الشروط الكاملة: ملف LICENSE
### 📬 Discord: iaf0 | GitHub: https://github.com/iiaf1
### ══════════════════════════════════════════════════════════════════
