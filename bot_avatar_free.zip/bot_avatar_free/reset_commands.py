#!/usr/bin/env python3
### ══════════════════════════════════════════════════════════════════
### Bot Avatar Free
### © 2026 iaf1 — جميع الحقوق محفوظة | All Rights Reserved.
### 🚫 البيع ممنوع منعًا باتًا | Selling is strictly PROHIBITED.
### ✅ ملفات مجانية 100% | These files are 100% FREE.
### ⚠️ إخلاء مسؤولية: مقدّمة "كما هي" بدون أي ضمان، والمؤلف غير مسؤول
###    عن أي ضرر أو خسارة أو سوء استخدام ناتج عنها.
### 📄 الشروط الكاملة: ملف LICENSE
### 📬 Discord: iaf0 | GitHub: https://github.com/iiaf1
### ══════════════════════════════════════════════════════════════════
"""
سكربت يُشغّل *مرة وحدة بس* لمسح كل الأوامر المسجّلة — عالمي + أي أوامر
مسجّلة محليًا (guild-scoped) بأي سيرفر البوت فيه حاليًا — عشان يحل مشكلة
تكرار الأوامر (زي /av اللي طلع مرتين بقائمة "/"). بعد ما يخلص، شغّل
bot.py عادي.

سبب التكرار الشائع: أمر اتسجل مرة "عالمي" ومرة "محلي" (guild command)
لنفس السيرفر بنفس الوقت (مثلاً وقت تجربة سابقة باستخدام TEST_GUILD_ID) —
ديسكورد يعرض النسختين لين تتنظف واحدة منهم. هذا السكربت يمسح الاثنين.

ملاحظة: لازم البوت يكون *داخل* السيرفر وقت تشغيل هذا السكربت عشان يقدر
يمسح أوامره المحلية فيه. إذا برضو يطلع تكرار بعدها، راجع أيضًا Discord
Developer Portal → تطبيقك → Installation، وتأكد إن مفعّل عندك سياق واحد
بس (Guild Install) — لأن تفعيل User Install مع Guild Install بنفس الوقت
يخلي الأمر يظهر مرتين بقائمة "/" حتى لو ما فيه تكرار فعلي بالتسجيل.

Setup: تأكد إن .env فيه DISCORD_TOKEN.

تشغيل:
    python3 reset_commands.py
"""

import os

import discord
from discord import app_commands
from dotenv import load_dotenv

__author__ = "iaf1"
__copyright__ = "Copyright (c) 2026 iaf1. All Rights Reserved."
__license__ = "Bot Avatar Free License - Free use only, selling strictly prohibited (see LICENSE)"

load_dotenv()
TOKEN = os.getenv("DISCORD_TOKEN")

intents = discord.Intents.default()
client = discord.Client(intents=intents)
tree = app_commands.CommandTree(client)


@client.event
async def on_ready():
    print(f"Logged in as {client.user} — بدأ التنظيف...")

    # 1) امسح كل الأوامر العالمية (Global)
    tree.clear_commands(guild=None)
    await tree.sync()
    print("✅ اتمسحت الأوامر العالمية (قد تاخذ لين ساعة تختفي من كل السيرفرات).")

    # 2) امسح أي أوامر محلية (guild-scoped) بكل سيرفر البوت عضو فيه حاليًا
    #    — هذا اللي يحل التكرار الناتج عن تجربة سابقة بـ TEST_GUILD_ID.
    for guild in client.guilds:
        tree.clear_commands(guild=guild)
        await tree.sync(guild=guild)
        print(f"✅ اتمسحت الأوامر المحلية بسيرفر: {guild.name} ({guild.id})")

    print("خلص التنظيف. دحين شغّل bot.py عادي عشان يسجّل الأوامر من جديد بدون تكرار.")
    print("© 2026 iaf1 — All Rights Reserved | Free • Selling PROHIBITED | Discord: iaf0 | https://github.com/iiaf1")
    await client.close()


if __name__ == "__main__":
    if not TOKEN:
        raise SystemExit("حط توكن البوت داخل ملف .env باسم DISCORD_TOKEN=...")
    client.run(TOKEN)

### ══════════════════════════════════════════════════════════════════
### Bot Avatar Free
### © 2026 iaf1 — جميع الحقوق محفوظة | All Rights Reserved.
### 🚫 البيع ممنوع منعًا باتًا | Selling is strictly PROHIBITED.
### ✅ ملفات مجانية 100% | These files are 100% FREE.
### ⚠️ إخلاء مسؤولية: مقدّمة "كما هي" بدون أي ضمان، والمؤلف غير مسؤول
###    عن أي ضرر أو خسارة أو سوء استخدام ناتج عنها.
### 📄 الشروط الكاملة: ملف LICENSE
### 📬 Discord: iaf0 | GitHub: https://github.com/iiaf1
### ══════════════════════════════════════════════════════════════════
