#!/usr/bin/env python3
### ══════════════════════════════════════════════════════════════════
### Bot Avatar Free
### © 2026 iaf1 — جميع الحقوق محفوظة | All Rights Reserved.
### 🚫 البيع ممنوع منعًا باتًا | Selling is strictly PROHIBITED.
### ✅ ملفات مجانية 100% | These files are 100% FREE.
### ⚠️ إخلاء مسؤولية: مقدّمة "كما هي" بدون أي ضمان، والمؤلف غير مسؤول
###    عن أي ضرر أو خسارة أو سوء استخدام ناتج عنها.
### 📄 الشروط الكاملة: ملف LICENSE
### 📬 Discord: iaf0 | GitHub: https://github.com/iiaf1
### ══════════════════════════════════════════════════════════════════
"""
Discord bot: /av — يحط صورة العضو داخل تصميم الإطار وينشرها بدون أي أثر
لاستخدام الأمر (ما يظهر "فلان used /av")، وبدون أي نص فوق الصورة.

تدفق الأزرار:
    1) /av تنشر رسالة عامة بالقناة: الصورة المؤطرة (بالإطار) + زر "تحميل".
    2) أي أحد يضغط "تحميل" -> تطلع له نفس الصورة المؤطرة بشكل مخفي
       (ephemeral، هو بس اللي يشوفها) مع زر "إرسال" تحتها.
    3) يضغط "إرسال" -> البوت يبعث له الصورتين **الأصليتين منفصلتين**
       (الصورة + الخلفية بدون الإطار) في الخاص (DM).

أمر /mm — تحديد رتبة الوصول تلقائيًا (بدون لمس .env):
    - أي مالك سيرفر أو عضو عنده صلاحية Administrator يقدر يكتب
      /mm رتبة:<اختر الرتبة> داخل سيرفره.
    - البوت يخزّن هذي الرتبة تلقائيًا (ملف guild_roles.json) خاصة
      بهذا السيرفر بالذات، وبعدها أي عضو معه هذي الرتبة يقدر يستخدم
      /av. تقدر تغيّرها أي وقت بإعادة تشغيل /mm برتبة ثانية.
    - صاحب البوت (BOT_OWNER_ID) دايم عنده صلاحية كاملة بكل سيرفر،
      بغض النظر عن الرتبة المحددة.

القيود:
    - الأمر /av ما يشتغل إلا لصاحب البوت (BOT_OWNER_ID) أو لعضو معه
      الرتبة اللي حددها /mm بنفس السيرفر. أي حد ثاني يوصله رد مخفي
      إنه ما عنده صلاحية.
    - الأمر /mm نفسه ما يظهر ولا يشتغل إلا لصاحب البوت أو لعضو عنده
      صلاحية Administrator بالسيرفر.

Setup:
    1. pip install -r requirements.txt
    2. عبّي ملف .env (بس هذولا):
           DISCORD_TOKEN=00000000000000000000000000000000000000000000000000000000000000000
           BOT_OWNER_ID=000000000000000000
    3. python3 bot.py
    4. داخل أي سيرفر تبي تفعّل فيه البوت: شغّل /mm وحدد الرتبة
       المسموح لها تستخدم /av — ينحفظ تلقائيًا، ما تحتاج تعدّل أي ملف.

الاستخدام داخل ديسكورد:
    /av صورة:<ارفاق الصورة>  خلفية:<ارفاق خلفية (اختياري)>
    /mm رتبة:<اختر الرتبة>
"""

import io
import json
import os
from pathlib import Path

import discord
from discord import app_commands
from dotenv import load_dotenv

from compositor import make_framed

__author__ = "iaf1"
__copyright__ = "Copyright (c) 2026 iaf1. All Rights Reserved."
__license__ = "Bot Avatar Free License - Free use only, selling strictly prohibited (see LICENSE)"

NOTICE = (
    "══════════════════════════════════════════════════════════════════\n"
    " Bot Avatar Free — © 2026 iaf1 — جميع الحقوق محفوظة | All Rights Reserved\n"
    " 🚫 البيع ممنوع منعًا باتًا | Selling is strictly PROHIBITED\n"
    " ✅ ملفات مجانية 100% | These files are 100% FREE\n"
    " ⚠️ مقدّمة \"كما هي\" بدون أي ضمان — المؤلف غير مسؤول عن أي ضرر\n"
    " 💬 Discord: iaf0 | 🐙 GitHub: https://github.com/iiaf1\n"
    "══════════════════════════════════════════════════════════════════"
)

load_dotenv()
TOKEN = os.getenv("DISCORD_TOKEN")


def _as_int(env_name: str) -> int | None:
    val = os.getenv(env_name)
    if val and val.strip().isdigit():
        return int(val.strip())
    return None


BOT_OWNER_ID = _as_int("BOT_OWNER_ID")

# ---------------------------------------------------------------------
# تخزين رتبة الوصول لكل سيرفر (بديل REQUIRED_ROLE_ID اليدوي بـ .env).
# يتحدّث تلقائيًا كل ما أحد يستخدم /mm — ما يحتاج تعديل أي ملف يدويًا.
# ---------------------------------------------------------------------
CONFIG_PATH = Path(__file__).parent / "guild_roles.json"


def _load_guild_roles() -> dict[str, int]:
    if CONFIG_PATH.exists():
        try:
            return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def _save_guild_role(guild_id: int, role_id: int) -> None:
    data = _load_guild_roles()
    data[str(guild_id)] = role_id
    CONFIG_PATH.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _get_guild_role(guild_id: int) -> int | None:
    return _load_guild_roles().get(str(guild_id))


intents = discord.Intents.default()
intents.members = True  # عشان نقدر نشوف رتب الأعضاء بدقة
client = discord.Client(intents=intents)
tree = app_commands.CommandTree(client)


def has_access(interaction: discord.Interaction) -> bool:
    """صاحب البوت دايم مسموح له بكل سيرفر. غيره لازم يكون معه الرتبة
    اللي تحددت بـ /mm لنفس هذا السيرفر بالذات."""
    user = interaction.user
    if BOT_OWNER_ID and user.id == BOT_OWNER_ID:
        return True
    if interaction.guild is None or not isinstance(user, discord.Member):
        return False
    required_role_id = _get_guild_role(interaction.guild.id)
    if not required_role_id:
        # ما حد سوّى /mm بعد بهذا السيرفر؟ نرفض الكل غير المالك احتياطًا
        return False
    return any(role.id == required_role_id for role in user.roles)


def can_manage_access_role(interaction: discord.Interaction) -> bool:
    """مين يقدر يستخدم /mm نفسه: صاحب البوت، أو عضو عنده Administrator
    بنفس السيرفر."""
    user = interaction.user
    if BOT_OWNER_ID and user.id == BOT_OWNER_ID:
        return True
    if interaction.guild is None or not isinstance(user, discord.Member):
        return False
    return user.guild_permissions.administrator


class SendView(discord.ui.View):
    """المرحلة الثانية: زر (إرسال) يبعث الصورتين الأصليتين (بدون الإطار)
    منفصلتين في الخاص."""

    def __init__(self, photo_bytes: bytes, photo_name: str, bg_bytes: bytes | None, bg_name: str | None):
        super().__init__(timeout=180)
        self.photo_bytes = photo_bytes
        self.photo_name = photo_name
        self.bg_bytes = bg_bytes
        self.bg_name = bg_name

    @discord.ui.button(label="إرسال", emoji="📤", style=discord.ButtonStyle.secondary)
    async def send_dm(self, interaction: discord.Interaction, button: discord.ui.Button):
        try:
            files = [discord.File(io.BytesIO(self.photo_bytes), filename=self.photo_name)]
            if self.bg_bytes:
                files.append(discord.File(io.BytesIO(self.bg_bytes), filename=self.bg_name))
            await interaction.user.send(files=files)
            await interaction.response.send_message("✅ تم إرسال صورك الأصلية لك في الخاص!", ephemeral=True)
        except discord.Forbidden:
            await interaction.response.send_message(
                "⚠️ ما قدرت أرسل لك، افتح الخاص عندك للجميع وحاول مرة ثانية.",
                ephemeral=True,
            )


class DownloadView(discord.ui.View):
    """المرحلة الأولى: زر (تحميل) يعرض الصورة المؤطرة بشكل مخفي مع زر
    إرسال تحتها (اللي يبعث الأصليتين منفصلتين).

    ملاحظة: ديسكورد ما يدعم ألوان مخصصة (hex) للأزرار — بس 5 أنماط ثابتة
    (Primary/Secondary/Success/Danger/Link)، فاستخدمنا Secondary (الرمادي)
    كأقرب شي متاح.
    """

    def __init__(
        self,
        framed_bytes: bytes,
        photo_bytes: bytes,
        photo_name: str,
        bg_bytes: bytes | None,
        bg_name: str | None,
    ):
        super().__init__(timeout=None)
        self.framed_bytes = framed_bytes
        self.photo_bytes = photo_bytes
        self.photo_name = photo_name
        self.bg_bytes = bg_bytes
        self.bg_name = bg_name

    @discord.ui.button(label="تحميل", emoji="⬇️", style=discord.ButtonStyle.secondary)
    async def download(self, interaction: discord.Interaction, button: discord.ui.Button):
        file = discord.File(io.BytesIO(self.framed_bytes), filename="preview.png")
        view = SendView(self.photo_bytes, self.photo_name, self.bg_bytes, self.bg_name)
        await interaction.response.send_message(file=file, view=view, ephemeral=True)


@tree.command(name="av", description="يحط صورتك داخل تصميم الإطار")
@app_commands.describe(
    صورة="الصورة اللي بتنحط داخل الدائرة",
    خلفية="صورة الخلفية اللي بتنحط ورا الدائرة (اختياري)",
)
async def avatar_cmd(
    interaction: discord.Interaction,
    صورة: discord.Attachment,
    خلفية: discord.Attachment = None,
):
    # ---- قيد الرتبة/المالك ----
    if not has_access(interaction):
        await interaction.response.send_message(
            "⚠️ ما عندك صلاحية تستخدم هذا الأمر.", ephemeral=True
        )
        return

    # نخلي رد التفاعل نفسه مخفي (ephemeral) عشان ما يطلع "فلان used /av"
    # للأعضاء الثانين — بعدين ننشر الصورة كرسالة عادية من البوت.
    await interaction.response.defer(ephemeral=True)

    photo_raw = await صورة.read()
    bg_raw = await خلفية.read() if خلفية else None

    try:
        result = make_framed(io.BytesIO(photo_raw), io.BytesIO(bg_raw) if bg_raw else None)
    except Exception as e:
        await interaction.followup.send(f"⚠️ صار خطأ وأنا أسوي الافتار: {e}", ephemeral=True)
        return

    buf = io.BytesIO()
    result.save(buf, format="PNG")
    framed_bytes = buf.getvalue()

    # ننشر الصورة المؤطرة كرسالة عادية بالقناة (بدون أي نص فوقها) + زر تحميل
    view = DownloadView(
        framed_bytes,
        photo_raw, صورة.filename,
        bg_raw, خلفية.filename if خلفية else None,
    )
    await interaction.channel.send(
        file=discord.File(io.BytesIO(framed_bytes), filename="avatar.png"),
        view=view,
    )

    await interaction.followup.send("✅", ephemeral=True)


@tree.command(name="mm", description="تحديد الرتبة المسموح لها تستخدم /av بهذا السيرفر")
@app_commands.describe(رتبة="الرتبة اللي تبيها تصير مسموحة تستخدم /av بهذا السيرفر")
@app_commands.default_permissions(administrator=True)
@app_commands.guild_only()
async def set_access_role_cmd(interaction: discord.Interaction, رتبة: discord.Role):
    # ---- قيد الصلاحية: بس المالك أو أدمن بنفس السيرفر ----
    if not can_manage_access_role(interaction):
        await interaction.response.send_message(
            "⚠️ ما عندك صلاحية تستخدم هذا الأمر (بس المالك أو الأدمن).",
            ephemeral=True,
        )
        return

    _save_guild_role(interaction.guild.id, رتبة.id)

    await interaction.response.send_message(
        f"✅ تم تحديد رتبة {رتبة.mention} — من الحين أي عضو معه هذي الرتبة يقدر يستخدم /av بهذا السيرفر.\n"
        "الحفظ صار تلقائيًا (ما تحتاج تعدّل أي ملف)، وتقدر تغيّرها أي وقت بإعادة استخدام /mm.",
        ephemeral=True,
    )


@tree.command(name="by", description="حقوق الملكية والتواصل الخاصة بالبوت")
async def copyright_cmd(interaction: discord.Interaction):
    # أمر عام بدون أي قيد — أي شخص بأي سيرفر أو حتى بالخاص يقدر يستخدمه.
    embed = discord.Embed(
        title="© Bot Avatar Free",
        description=(
            "مشروع **مجاني 100%** — جميع الأكواد والملفات (بما فيها تصميم الإطار) "
            "من تأليف وملكية **iaf1**.\n"
            "جميع الحقوق محفوظة © 2026."
        ),
        color=discord.Color.gold(),
    )
    embed.add_field(name="👤 المؤلف / المالك", value="iaf1", inline=True)
    embed.add_field(name="💬 Discord", value="`iaf0`", inline=True)
    embed.add_field(name="🐙 GitHub", value="https://github.com/iiaf1", inline=False)
    embed.add_field(
        name="🚫 البيع ممنوع",
        value=(
            "يُمنع منعًا باتًا بيع الملفات أو أي جزء منها أو نسخ معدّلة منها، "
            "أو وضعها خلف اشتراك/رتبة مدفوعة/روابط مربحة. "
            "إذا اشتريتها من أحد فهذا بيع مخالف — تواصل مع المؤلف."
        ),
        inline=False,
    )
    embed.add_field(
        name="📄 الرخصة",
        value=(
            "استخدام ونسخ وتعديل ومشاركة **مجانية** فقط، بشرط إبقاء إشعار "
            "حقوق الملكية والرخصة مرفقين. التفاصيل الكاملة بملف `LICENSE`."
        ),
        inline=False,
    )
    embed.add_field(
        name="⚠️ إخلاء مسؤولية",
        value=(
            "الملفات مقدّمة \"كما هي\" بدون أي ضمان، والمؤلف غير مسؤول عن أي "
            "ضرر أو خسارة أو سوء استخدام، أو عن أي حظر لحساب أو بوت، "
            "ولا يتبع هذا المشروع ديسكورد."
        ),
        inline=False,
    )
    embed.set_footer(text="© 2026 iaf1 — All Rights Reserved | Free • No Sale")

    await interaction.response.send_message(embed=embed)


@client.event
async def on_ready():
   
    await tree.sync()

    activity = discord.Streaming(name="by iaf0", url="https://www.twitch.tv/discord")
    await client.change_presence(activity=activity, status=discord.Status.online)

    print("Synced commands globally (may take up to 1 hour to appear everywhere)")
    print(f"Logged in as {client.user}")
    print(NOTICE)


if __name__ == "__main__":
    print(NOTICE)
    if not TOKEN:
        raise SystemExit("حط توكن البوت داخل ملف .env باسم DISCORD_TOKEN=...")
    client.run(TOKEN)

### ══════════════════════════════════════════════════════════════════
### Bot Avatar Free
### © 2026 iaf1 — جميع الحقوق محفوظة | All Rights Reserved.
### 🚫 البيع ممنوع منعًا باتًا | Selling is strictly PROHIBITED.
### ✅ ملفات مجانية 100% | These files are 100% FREE.
### ⚠️ إخلاء مسؤولية: مقدّمة "كما هي" بدون أي ضمان، والمؤلف غير مسؤول
###    عن أي ضرر أو خسارة أو سوء استخدام ناتج عنها.
### 📄 الشروط الكاملة: ملف LICENSE
### 📬 Discord: iaf0 | GitHub: https://github.com/iiaf1
### ══════════════════════════════════════════════════════════════════
